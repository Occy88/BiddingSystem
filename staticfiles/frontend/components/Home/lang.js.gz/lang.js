const languages = {
    'en-us': {
        example_text: 'Now serving the example page, Project is online and functional'
    },
    'fr': {
        example_text: 'salut'

    },
    'it': {
        example_text: 'porco'


    },
    'es': {
        example_text: 'hola'


    },

};
export default languages;